const buttonTag = document.querySelector(".btn-primary");
const toastAlertTag = document.querySelector(".toastAlert");

buttonTag.addEventListener("click", () => {
  toastAlertTag.style.bottom = "0px";
  setTimeout(() => {
    toastAlertTag.style.bottom = "-40px";
  }, 3000);
});
